<?php
include 'koneksi.php';
session_start();
// semisal belum login, langsung masuk ke index.php
if (!isset($_SESSION['username'])) {
  header("Location: index.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>DeliVer</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body>
  <header>
    <nav class="navbar fixed-top" style="background-color: #7C4646; padding: 20px;">
      <ul>
      <img src="img/logonav.svg" alt="Logo WSD" style="text-align: left; width: 70px;">
      </ul>
      <ul>
        <li><a href="homepage.php">Home</a></li>
        <li class="dropdown"><a href="shop.php" class=" dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Kategori</a>
          <ul class="dropdown-menu">
            <li><a href="kategori.php?tag=Protein" class="dropdown-item">Protein</a></li>
            <li><a href="kategori.php?tag=Sayuran" class="dropdown-item">Sayuran</a></li>
            <li><a href="kategori.php?tag=Buah" class="dropdown-item">Buah</a></li>
            <li><a href="kategori.php?tag=Bumbu" class="dropdown-item">Bumbu</a></li>
            <li><a href="kategori.php?tag=Snack" class="dropdown-item">Snack</a></li>
            <li><a href="kategori.php?tag=Minuman" class="dropdown-item">Minuman</a></li>
          </ul>
        </li>
        <li style="margin-left: 750px;"> <img src="img/cart.svg" alt="Cart"> <a href="cart.php"></a></li>
        </a></li>
             <li> <a href="history.php">
            <img src="img/history.svg" alt="history">
          </a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </nav>
  </header>
  <section id="promo">
    <H1>PAYMENT METHOD</H1>
    <br>
    <h2>Transfer via M-Banking</h2>
    <h3>No VA Billing: 0947264917</h3>
    <br>
    <h2>QRIS</h2>
    <h3><img src="img/barcode1.png" alt="" style="width: 200px"></h3>
    <td><a href="checkout.php" class="btn text-light" style="background-color: #847D7D" ; onclick="myalert()">Checkout</a></td>

  </section>

  <script> 
            function myalert() { 
            alert("Checking Payment:\n " + 
                "Payment Successful "); 
        } 
    </script> 

  <footer style="position: absolute;"> &copy; 2024 WSD. All rights reserved.</footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="script.js"></script>

</body>

</html>